/**
 * Created by User11 on 11.08.2015.
 */

/*$(document).ready(function(){
    $('img').error(function(){



            $(this).attr('src', './assets/front/logo_uch.png');



    });
});*/